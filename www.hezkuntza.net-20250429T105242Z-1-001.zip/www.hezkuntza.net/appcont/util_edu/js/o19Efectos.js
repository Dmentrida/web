//---------------------------------------------------------
//
//  30-10-2003 (Jose)
//
//  Libreria JavaScript para efectos.
//
//---------------------------------------------------------

//---------------------------------------------------------
// Funcion para indicar que se esta en espera.
// Utilizar en las peticiones html de espera prolongada.
// Recibe el texto y la referencia al div donde se mostrara el texto.
// Ejemplo en /appcont/control_acceso/index.html

function iniciarEspera(textoEspera,capaEspera)
{
   txtTextoPasado=textoEspera;
	txtEsperando="(" + textoEspera + ")";

	varCapaEspera=capaEspera;
	varCapaEspera.innerHTML=txtEsperando;
	setInterval(cambiaTexto,500);

}

// Funcion de apoyo a la funcion iniciarEspera.

function cambiaTexto()
{
	(txtEsperando=="((((((" + txtTextoPasado + "))))))")? txtEsperando="(" + txtTextoPasado + ")" : txtEsperando="("+txtEsperando+")"
	varCapaEspera.innerHTML=txtEsperando;
}
//---------------------------------------------------------